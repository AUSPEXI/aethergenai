auspexi
